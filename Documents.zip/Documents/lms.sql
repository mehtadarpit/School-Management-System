-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 19, 2021 at 10:46 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Addclass` (IN `class_name` VARCHAR(45), IN `teacher_id` INT, IN `section_name` VARCHAR(45))  begin
declare id int;
set id = (select max(Section_ID) from Section);
insert into ClassRoom(Class_Description) values (class_name);
insert into Section values (id+1,classid,teacher_id,section_name);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AddEmployee1` (IN `emp_fname` VARCHAR(30), IN `emp_lname` VARCHAR(30), IN `emp_email` VARCHAR(30), IN `emp_pass` VARCHAR(30), IN `emp_dob` DATE, IN `emp_telno` VARCHAR(20), `emp_mobno` VARCHAR(20), `emp_doj` DATE, `emp_status` VARCHAR(30), `emp_gender` VARCHAR(10), `emp_roleid` INT, `emp_salary` DECIMAL(10,0))  begin
insert into Employee(E_Fname,E_Lname,E_Email,E_Pass,E_DOB,E_TelNo,E_MobileNo,E_DOJ,E_Status,E_Gender,E_RoleID,E_Salary) values(emp_fname,emp_lname,emp_email,emp_pass,emp_dob,emp_telno,emp_mobno,emp_doj,emp_status,emp_gender,
emp_roleid,emp_salary);
End$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AddExam` (IN `e_id` INT, IN `e_typeid` INT, IN `e_cid` INT, `e_starttime` DATETIME, IN `e_subid` INT)  begin
insert into Exam values(e_id,e_typeid,e_cid,e_starttime,e_subid);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AddFees` (IN `F_ID` INT, IN `F_stdid` INT, IN `F_PC` DECIMAL(10,0), IN `F_Issuedate` DATETIME, IN `F_duedate` DATETIME, IN `F_discount` DECIMAL(10,2), IN `F_DR` VARCHAR(70), IN `Feesstatus` VARCHAR(45), IN `Fees_amount` DECIMAL(10,0), IN `Fees_AC` DECIMAL(10,0), IN `paiddate` DATE)  begin
insert into AddFees values(F_ID,F_stdid,F_PC,F_Issuedate,F_duedate,F_discount,F_DR,Feesstatus,Fees_amount,Fees_AC,paiddate);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AddResult` (IN `R_Id` INT, `R_EType` INT, IN `R_total` DECIMAL(10,0), IN `R_Obtain` DECIMAL(10,0), IN `R_grade` VARCHAR(45), IN `R_Percent` DECIMAL(10,3), IN `R_Stdid` INT)  begin
insert into Result values (R_Id,R_EType,R_Total,R_Obtain,R_grade,R_Percent,R_Stdid);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AddStudent` (IN `std_id` INT, IN `std_Fname` VARCHAR(30), IN `std_Lname` VARCHAR(30), IN `std_Email` VARCHAR(30), IN `std_Pass` VARCHAR(30), IN `std_DOB` DATE, IN `std_telno` VARCHAR(20), IN `std_Mobno` VARCHAR(20), IN `std_DOA` DATE, IN `std_Status` VARCHAR(30), IN `std_gender` VARCHAR(10), IN `std_cid` INT, IN `std_secid` INT, IN `std_guardianid` INT)  begin
insert into Student values(std_id,std_Fname,std_Lname,std_Email,std_Pass,std_DOB,
std_DOB,std_telno,std_Mobno,std_DOA,std_Status,std_gender,std_cid,std_secid,std_guardianid);
End$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AddSubject` (IN `subject_id` INT, IN `Subject_name` VARCHAR(50), IN `Subject_classid` INT, IN `subject_description` VARCHAR(60))  begin
insert into Subjects values(subject_id,Subject_name,Subject_classid,subject_description);
End$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AddSubjectteaches` (IN `id` INT, IN `subteachby` INT, IN `subjectteach_cid` INT, IN `startdate` DATE, IN `S_enddate` DATE, IN `dropstatus` VARCHAR(45), IN `outcome` VARCHAR(70), IN `subject_id` INT)  begin
insert into SubjectTeaches values (id,subteachby,subjectteach_cid,startdate,S_enddate,dropstatus,outcome,subject_id);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AddTimetable` (IN `id` INT, `secid` INT, IN `Day` VARCHAR(10), IN `starttime` TIME, IN `description` VARCHAR(60), IN `subid` INT, IN `endtime` TIME)  begin
insert into TimeTable values(id,secid,Day,starttime,description,subid,endtime);
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditAttendance` (IN `sid` INT, IN `remarks` VARCHAR(20), IN `status` VARCHAR(20), IN `date` DATETIME)  begin
update Attendance set A_Remarks = remarks ,A_Status = status ,A_Date = date where A_StdID = sid; 
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Editclass` (IN `classid` INT, IN `class_name` VARCHAR(45), IN `teacher_id` INT, IN `section_name` VARCHAR(45))  begin
declare id int;
set id = (select Section_ID from Section s where s.Section_ClassID = classid and s.Section_UnderObservation = teacher_id and s.Section_Name = section_name);
update ClassRoom set  Class_Description = class_name where Class_ID = classid;
update Section s set s.Section_ClassID = classid , s.Section_UnderObservation = teacher_id , s.Section_Name = section_name
where Section_ID = id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditEmployee` (IN `emp_id` INT, IN `emp_fname` VARCHAR(30), IN `emp_lname` VARCHAR(30), IN `emp_email` VARCHAR(30), IN `emp_pass` VARCHAR(30), IN `emp_dob` DATE, IN `emp_telno` VARCHAR(20), `emp_mobno` VARCHAR(20), `emp_doj` DATE, `emp_status` VARCHAR(30), `emp_gender` VARCHAR(10), `emp_roleid` INT, `emp_salary` DECIMAL(10,0))  begin
update Employee set E_Fname = emp_fname,E_Lname = emp_lname,E_Email = emp_email,E_Pass = emp_pass,E_DOB = emp_dob,
E_TelNo = emp_telno,E_MobileNo = emp_mobno,E_DOJ = emp_doj,E_Status = emp_status,E_Gender = emp_gender,
E_RoleID = emp_roleid, E_Salary = emp_salary where  E_ID=emp_id;
End$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditExam` (IN `e_id` INT, IN `e_typeid` INT, IN `e_cid` INT, `e_starttime` DATETIME, IN `e_subid` INT)  begin
update Exam set Exam_TypeID = e_typeid ,Exam_ClassID = e_cid,Exam_Start_DateTime = e_starttime, Exam_SubjectID = e_subid where Exam_ID = e_id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditFees` (IN `F_ID` INT, IN `F_stdid` INT, IN `F_PC` DECIMAL(10,0), IN `F_Issuedate` DATETIME, IN `F_duedate` DATETIME, IN `F_discount` DECIMAL(10,2), IN `F_DR` VARCHAR(70), IN `Feesstatus` VARCHAR(45), IN `Fees_amount` DECIMAL(10,0), IN `Fees_AC` DECIMAL(10,0), IN `paiddate` DATE)  begin
update AddFees Set Fees_StdID = F_stdid,Fees_PreviousCharges = F_PC,Fees_IssueDateTime = F_Issuedate,Fees_DueDateTime = F_duedate,Fees_Discount = F_discount,Fees_DiscountReason = F_DR,FeesStatus=Feesstatus,Fees_Amount = Fees_amount,Fees_AdditionalCharges = Fees_AC,Fees_PaidDate = paiddate where Fees_ID = F_ID;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditGuardian` (IN `id` INT, IN `gr_fname` VARCHAR(30), IN `gr_lname` VARCHAR(30), IN `gr_email` VARCHAR(30), IN `gr_pass` VARCHAR(30), IN `gr_cnic` VARCHAR(20), IN `gr_telno` VARCHAR(20), IN `gr_mobno` VARCHAR(20), IN `gr_address` VARCHAR(100), IN `gr_relationship` VARCHAR(100))  begin
update Guardian set Gr_Fname = gr_fname,Gr_Lname = gr_lname, Gr_Email = gr_email,Gr_Pass = gr_pass,Gr_CNIC = gr_cnic,
Gr_TelNo = gr_telno,Gr_MobileNo = gr_mobno,Gr_Address = gr_address,Gr_Relationship = gr_relationship 
where Gr_Id = id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditResult` (IN `R_Id` INT, `R_EType` INT, IN `R_total` DECIMAL(10,0), IN `R_Obtain` DECIMAL(10,0), IN `R_grade` VARCHAR(45), IN `R_Percent` DECIMAL(10,3), IN `R_Stdid` INT)  begin
update Result set Result_ExamTypeID = R_EType,Result_TotalMarks = R_Total,Result_ObtainMarks = R_Obtain,Result_Grade = R_grade,Result_Percentage = R_Percent,Result_StdID = R_Stdid  where Result_ID = R_Id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditStudent` (IN `id` INT, IN `std_fname` VARCHAR(30), IN `std_lname` VARCHAR(30), IN `std_email` VARCHAR(30), IN `std_pass` VARCHAR(30), IN `std_dob` DATE, IN `std_telno` VARCHAR(20), IN `std_Mobno` VARCHAR(20), IN `std_doa` DATE, IN `std_status` VARCHAR(30), IN `std_gender` VARCHAR(10), IN `std_cid` INT, IN `std_secid` INT, IN `std_guardianid` INT)  begin
update Student set Std_Fname = std_fname,Std_Lname = std_lname, Std_Email = std_email,Std_Pass = std_pass,
Std_DOb = std_dob,Std_TelNo = std_telno, Std_MobileNo = std_Mobno,Std_DOA = std_doa, Std_Status = std_status,
Std_Gender = std_gender,Std_ClassID = std_cid, Std_SectionID = std_secid,Std_GuardianID = std_guardianid
where Std_Id = id;
End$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditSubject` (IN `subject_id` INT, IN `Subject_name` VARCHAR(50), IN `Subject_classid` INT, IN `subject_description` VARCHAR(60))  begin
update Subjects set Subject_Name = Subject_name ,Subject_ClassID = Subject_classid,Subject_Description = subject_description 
where Subject_ID = subject_id;
End$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditSubjectteaches` (IN `id` INT, IN `subteachby` INT, IN `subjectteach_cid` INT, IN `startdate` DATE, IN `S_enddate` DATE, IN `dropstatus` VARCHAR(45), IN `outcome` VARCHAR(70), IN `subject_id` INT)  begin
update SubjectTeaches set SubjectTeachesBy = subteachby, SubjectTeachesClassID = subjectteach_cid,SubjectTeachesStartDate = startdate,SubjectTeachesEndDate = S_enddate,SubjectTeachesDropStatus = dropstatus,SubjectTeachesOutCome = outcome,SubjectTeaches_SubjectID = subject_id where idSubjectTeaches =  id;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EditTimetable` (IN `id` INT, `secid` INT, IN `Day` VARCHAR(10), IN `starttime` TIME, IN `description` VARCHAR(60), IN `subid` INT, IN `endtime` TIME)  begin
update TimeTable set TT_SectionID = secid,TT_Day = Day,TT_StartTime = starttime,TT_Description = description,TT_SubjectID = subid ,TT_EndTime = endtime where  TT_ID = id ;
end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `MarkAttendance` (IN `sid` INT, IN `remarks` VARCHAR(20), IN `status` VARCHAR(20), IN `date` DATETIME)  begin
insert into Attendance values (sid,remarks,status,date);
end$$
